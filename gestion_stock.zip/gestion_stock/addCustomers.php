<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/addCustomers.css">
</head>
	
<body>
	<?php 
		session_start();

		include 'includes/header.php';
		include 'includes/nav_vendeur.php';
	?>

	<section class="customers">
		<h1>INSERER CLIENT</h1>
		<form method="POST" action="actions/setCustomers.php">
			<div>
				<label for="last_name" class="label">NOM<span class="required"> * </span></label>
				<input id="last_name" type="text" minlength="3" maxlength="20" name="last_name" class="input" required pattern="{a-z,A-Z}"><br><br>
			</div>

			<div>
				<label for="first_name" class="label">PRENOM<span class="required"> * </span></label>
				<input id="first_name" type="text" minlength="3" maxlength="20" name="first_name" class="input" required pattern="{a-z,A-Z}"><br><br>
			</div>

			<div>
				<label for="nif" class="label">NIF<span class="required"> * </span></label>
				<input id="=nif" type="number" minlength="5" maxlength="5" name="nif" class="input" required pattern="{0-9}"><br><br>
			</div>
			
			<div>
				<label for="adress" class="label">ADRESSE<span class="required"> * </span></label>
				<input id="adress" type="text" minlength="5" maxlength="20" name="adress" class="input" required=""><br><br>
			</div>
			
			<div>
				<label for="postal_code" class="label">CODE POSTAL<span class="required"> * </span></label>
				<input id="postal_code" type="number" maxlength="4" minlength="4" name="postal_code" class="input" required pattern="{0-9}"><br><br>
			</div>

			<div>
				<label for="city" class="label">VILLE<span class="required"> * </span></label>
				<input id="city" type="text" minlength="3" maxlength="15" name="city" class="input" required><br><br>
			</div>
			
			<div>
				<label for="country" class="label">PAYS<span class="required"> * </span></label>
				<select id="country" name="country" class="select" required>
					<option value="France" selected>France</option>
					<option value="Haiti">Haiti</option>
					<option value="Usa">Usa</option>
					<option value="Chine">Chine</option>
					<option value="Chili">Chili</option>
				</select><br><br>
			</div>
			
			<div>
				<label for="telephone" class="label" required>TELEPHONE<span class="required"> * </span></label>
				<input id="telephone" type="text" name="telephone" class="input" required><br><br>
			</div>

			<div>
				<button type="submit" name="submit">INSERER</button>
				<button type="reset">EFFACER</button>
			</div>
		</form>
	</section>
	
</body>
</html>