<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="css\index.css">
</head>
<body>

	<?php
		if(isset($_GET['login']))
        {
            $conn = $_GET['login'];

             if($conn == 0)
             {
             	echo "<h3>Info itilizate invalid *</h3>";
             }	
         }
    ?>

	<div class="container" id="container">
		<div class="form-container sign-in-container">
			<form method="POST" action="actions/traitement_login.php">
				<h1>Connexion</h1>
				
				<input class="i1" type="text" name="fonction" id="fonction" required="" placeholder="Fonction">
				<input class="i2" type="password" name="password" id="password" required="" placeholder="Mot De Passe">
				<button type="submit">Soumettre</button>
			</form>
		</div>
	</div>
</body>
</html>