<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/list.css"/>
        <script src="sweetalert2@9"></script>
        <title>Liste clients</title>
    </head>

    <body>
       <?php
            session_start(); 

            if(isset($_GET['connect']))
            {
                $conn = $_GET['connect'];
                
                if($conn == 1 and isset($_GET['item_name']))
                { 
                    $item_name = $_GET['item_name'];
                    ?>

                    <script type="text/javascript">
                        alert("Article <?php echo "$item_name"; ?> Inserer !");
                    </script>
                <?php }


                else if($conn == 2 and isset($_GET['id_item']))
                { 
                    $id_item = $_GET['id_item']; ?>
                    <script type="text/javascript">
                        alert("Article ID <?php echo $id_item; ?> N'existe Pas");
                    </script>
                <?php }


                else if($conn == 3 and isset($_GET['id_item']) and isset($_GET['item_name']))
                { 
                    $id_item = $_GET['id_item'];
                    $item_name = $_GET['item_name']; ?>
                    <script type="text/javascript">
                        alert("Article ID <?php echo $id_item; ?> , Non <?php echo $item_name; ?> Supprimer");
                    </script>
                <?php }



                else if($conn == 4 and isset($_GET['id_item']) and isset($_GET['item_name']))
                { 
                    $id_item = $_GET['id_item'];
                    $item_name = $_GET['item_name']; ?>
                    <script type="text/javascript">
                        alert("Vous ne pouvez pas supprimer l'article ID <?php echo $id_item; ?>, De Nom <?php echo $item_name; ?> (Presence de cle etrangere sur cet Article)");
                    </script>
                <?php }
                



                else if($conn == 202 and isset($_GET['item_name']))
                {   $item_name = $_GET['item_name'];
                    ?>

                    <script type="text/javascript">
                        alert("Article <?php echo "$item_name"; ?> Existe Deja !")
                    </script>
                <?php }



                else if($conn == 203 and isset($_GET['id_item']))
                {   $id_item = $_GET['id_item'];
                    ?>

                    <script type="text/javascript">
                        alert("Article ID <?php echo "$id_item"; ?> Modifier !");
                    </script>
                <?php }



                else if($conn == 404 and isset($_GET['id_item']))
                { 
                    $id_item = $_GET['id_item'];
                    $item_name = $_GET['item_name'];
                ?>
                    <script type="text/javascript">
                        alert("Stock Article <?php echo "$item_name"; ?> De Referans <?php echo "$id_item"; ?> Insuffisant !");
                    </script>
                <?php }



                else if($conn == 406 and isset($_GET['id_item']))
                { 
                    $id_item = $_GET['id_item'];
                ?>
                    <script type="text/javascript">
                        alert("Article ID <?php echo "$id_item"; ?> Inexistant !");
                    </script>
                <?php #}


                // else if($conn == 407 and isset($_GET['id_client']) and isset($_GET['id_item']))
                // { 
                //     $id_client = $_GET['id_client'];
                //     $id_item = $_GET['id_item'];
                // ?>
                //     <script type="text/javascript">
                //         alert("Kliyan ID <?//php echo "$id_client"; ?> Ak Atik ID <?php //echo "$id_item"; ?> Pa Egziste !");
                //     </script>
                // <?php }


                else { 
                    ?>
                    <script type="text/javascript">
                        alert("Article Non Ajoute");
                    </script>
                <?php }?>
                    <script type="text/javascript">
                        window.location.href = "listItems.php";
                    </script> <?php
            }


            if ($_SESSION['fonction'] == "comptable") 
            {
                include './includes/header.php';
                include './includes/nav_comptable.php';
                include './connexion_db/config.php';
            
                $sql = "SELECT * FROM articles";
                echo "<section>";
                        echo "<h1>LISTE ARTICLES</h1>";
                            echo "<table>";
                                echo "<tr>";
                                    echo "<th>Reference</th>";
                                    echo "<th>Nom</th>";
                                    echo "<th>Description</th>";
                                    echo "<th>Quantite</th>";
                                    echo "<th>Prix</th>";   
                                echo "</tr>";
                if($result = mysqli_query($db, $sql))
                {
                    if(mysqli_num_rows($result) > 0)
                    {
                        

                                while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                        echo "<td>" . $row['reference'] . "</td>";
                                        echo "<td>" . $row['nom'] . "</td>";
                                        echo "<td>" . $row['description'] . "</td>";
                                        echo "<td>" . $row['quantite'] . "</td>";
                                        echo "<td>" . $row['prix'] . "</td>";                            
                                    echo "</tr>";
                                }

                                
                                // Free result set
                                mysqli_free_result($result);
                    }
                }
                echo "</table>"; 

                echo "</section>";
                 
                mysqli_close($db);
            }


            if ($_SESSION['fonction'] == "vendeur") 
            {
                include './includes/header.php';
                include './includes/nav_vendeur.php';
                include './connexion_db/config.php';
            
                $sql = "SELECT * FROM articles";
                echo "<section>";
                        echo "<h1>LIS ATIK</h1>";
                            echo "<table>";
                                echo "<tr>";
                                    echo "<th>Referans</th>";
                                    echo "<th>Non</th>";
                                    echo "<th>Deskripsyon</th>";
                                    echo "<th>Kantite</th>";
                                    echo "<th>Pri</th>";   
                                echo "</tr>";
                if($result = mysqli_query($db, $sql))
                {
                    if(mysqli_num_rows($result) > 0)
                    {
                        

                                while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                        echo "<td>" . $row['reference'] . "</td>";
                                        echo "<td>" . $row['nom'] . "</td>";
                                        echo "<td>" . $row['description'] . "</td>";
                                        echo "<td>" . $row['quantite'] . "</td>";
                                        echo "<td>" . $row['prix'] . " HTG". "</td>";                            
                                    echo "</tr>";
                                }

                                
                                // Free result set
                                mysqli_free_result($result);
                    }
                } 
                    echo "</table>";
                echo "</section>";
                 
                mysqli_close($db);
            }
        ?>
    </body>
</html>
