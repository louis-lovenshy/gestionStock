<?php
	session_start();

	if (isset($_POST['item_name']) and isset($_POST['item_desc']) and isset($_POST['item_qty']) and isset($_POST['item_price'])) 
	{
		include('..\connexion_db\config.php');

		$item_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_name']));
		$item_desc = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_desc']));
		$item_qty = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_qty']));
		$item_price = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_price']));
		$submit = mysqli_real_escape_string($db,htmlspecialchars($_POST['submit']));

		$test = "SELECT nom FROM articles WHERE nom = '".$item_name."' ";
		$exec_requete = mysqli_query($db,$test);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['nom'];

        if ($count == "") 
        {
        	$insertion = "INSERT INTO articles VALUES (null, '$item_name', '$item_desc', '$item_qty', '$item_price')";

		    if (mysqli_query($db, $insertion)) 
		    {
		        header("Location: ..\listItems.php?connect=1&item_name=$item_name");
		    }       

		    else
		    {
		        echo "ERROR: " .mysqli_error($db);
		    }
        }

        else
        {
        	header("Location: ..\listItems.php?connect=202&item_name=$item_name");
        }	
	}
?>