<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\css\addCustomers.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\nav.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\header.css">
</head>
<body>

</body>
</html>

<?php
	session_start();
	include '../actions/includes/header.php';
    include '../actions/includes/nav_vendeur.php';
?>


<?php
		if (isset($_POST['id_client']) and isset($_POST['submit_id']))
		{
			include('..\connexion_db\config.php');

			$id_client = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_client']));

			$requete = "SELECT count(*) FROM clients where numero = '".$id_client."' ";
	        $exec_requete = mysqli_query($db,$requete);
	        $reponse      = mysqli_fetch_array($exec_requete); 
	        $count = $reponse['count(*)'];

	        if($count != 0)
	        { ?>
	        	<section class="customers">
	        		<h1>MODIFYE</h1>
        		<?php $sql = "SELECT * FROM clients WHERE numero = '$id_client' ";
	            if($result = mysqli_query($db, $sql))
	            {
	                if(mysqli_num_rows($result) > 0)
	                {
	                    echo "<section>";
	                
                        while($row = mysqli_fetch_array($result))
                        {
                            
                        }

                        mysqli_free_result($result);
	                }
	            } 
	        } 

	        else
	        {
	        	header("Location: ..\listCustomers.php?connect=2&id_client=$id_client");
	        }


	        ?>

	    </section>
		<?php }
	?>


			<form method="POST" action="traitementUpdateCustomers.php">
				<div>
					<label for="id_client" class="label">Numero Client</label>
					<input id="id_client" type="number" name="id_client" class="input" value="<?php 
                        $sql = "SELECT numero FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['numero'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly
                        ><br><br>
				</div>

				<div>
					<label for="last_name" class="label">Nom</label>
					<input id="last_name" type="text" name="last_name" class="input" required value="<?php 
                        $sql = "SELECT nom FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['nom'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<label for="first_name" class="label">Prenom</label>
					<input id="first_name" type="text" name="first_name" class="input" required value="<?php 
                        $sql = "SELECT prenom FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['prenom'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<label for="nif" class="label">NIF</label>
					<input id="nif" type="number" name="nif" class="input" required value="<?php 
                        $sql = "SELECT nif FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['nif'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>
				
				<div>
					<label for="adress" class="label">Adresse</label>
					<input id="adress" type="text" name="adress" class="input" required value="<?php 
                        $sql = "SELECT adresse FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['adresse'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>
				
				<div>
					<label for="postal_code" class="label">Code postal</label>
					<input id="postal_code" type="number" name="postal_code" class="input" required value="<?php 
                        $sql = "SELECT codepostal FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['codepostal'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<label for="city" class="label">Ville</label>
					<input id="city" type="text" name="city" class="input" required value="<?php 
                        $sql = "SELECT ville FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['ville'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>
				
				<div>
					<label for="country" class="label">Pays</label>
					<select id="country" name="country" class="select" required value="<?php 
                        $sql = "SELECT pays FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['pays'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>">
						<option value="France" selected>France</option>
						<option value="Haiti">Haiti</option>
						<option value="Usa">Usa</option>
						<option value="Chine">Chine</option>
						<option value="Chili">Chili</option>
					</select><br><br>
				</div>
				
				<div>
					<label for="telephone" class="label" required>Telephone</label>
					<input id="telephone" type="text" name="telephone" class="input" required value="<?php 
                        $sql = "SELECT telephone FROM clients WHERE numero = '$id_client' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['telephone'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<button type="submit" name="submit_update">MODIFYE</button>
					<button type="reset">EFASE</button>
				</div>
			</form>
		</section>    	
    <?php
?>