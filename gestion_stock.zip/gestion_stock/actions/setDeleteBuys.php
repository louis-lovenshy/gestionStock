<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\css\addCustomers.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\nav.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\header.css">
</head>
<body>

</body>
</html>

<?php
	session_start();
	include '..\includes\header.php';
	include '..\includes\nav_vendeur.php';
	include '..\connexion_db\config.php'
?>

<?php
	if (isset($_POST['id_buy']) and isset($_POST['submit_id']))
	{
		include('..\connexion_db\config.php');

		$id_buy = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_buy']));

		$requete = "SELECT count(*) FROM achats where id_achat = '".$id_buy."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['count(*)'];

        if($count !== 0)
        {
    		$sql = "DELETE FROM achats WHERE id_achat = '$id_buy' ";

   //  		$test_4 = "SELECT nom FROM achats WHERE id_achat = '".$id_buy."' ";
			// $exec_requete_4 = mysqli_query($db,$test_4);
	  //       $reponse_4      = mysqli_fetch_array($exec_requete_4); 
	  //       $count_4 = $reponse_4['nom'];

            if(mysqli_query($db, $sql))
            {
            	header("Location: ..\listBuy.php?connect=300");
            }

            else
            {
            	header("Location: ..\listBuy.php?connect=400");
            } 
        } 

        else
        {
        	header("Location: ..\listBuy.php?connect=200");
        }

	}
?>