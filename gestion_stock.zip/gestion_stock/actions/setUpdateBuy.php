<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\css\addCustomers.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\nav.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\header.css">
</head>
<body>

</body>
</html>

<?php
	session_start();
	include '..\includes\header.php';
	include '..\includes\nav_vendeur.php';
	include '..\connexion_db\config.php'
?>

<?php
		if (isset($_POST['id_buy']) and isset($_POST['submit_id']))
		{
			include('..\connexion_db\config.php');

			$id_buy = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_buy']));

			$requete = "SELECT count(*) FROM achats where id_achat = '".$id_buy."' ";
	        $exec_requete = mysqli_query($db,$requete);
	        $reponse      = mysqli_fetch_array($exec_requete); 
	        $count = $reponse['count(*)'];

	        if($count == 1)
	        { ?>
	        	<section class="customers">
        		<?php $sql = "SELECT * FROM achats WHERE id_achat = '$id_buy' ";
	            if($result = mysqli_query($db, $sql))
	            {
	                if(mysqli_num_rows($result) > 0)
	                {
	                    echo "<section>";
	                        
                        // Free result set
                        mysqli_free_result($result);
	                }
	            } 
	        } 

	        else
	        {
	        	header("Location: ..\listBuy.php?connect=2&id_buy=$id_buy");
	        }


	        ?>

	    </section>
		<?php }
	?>


			<form method="POST" action="traitementUpdateBuy.php">
				<div>
					<label for="id_buy" class="label">ID Achat</label>
					<input id="id_buy" type="number" name="id_buy" class="input" value="<?php 
                        $sql = "SELECT id_achat FROM achats WHERE id_achat = '$id_buy' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['id_achat'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly
                        ><br><br>
				</div>


				<div>
					<label for="id_client" class="label">Numero client <span class="required"> * </span></label>
					<input id="id_client" type="number" min="1" name="id_client" class="input" required value="<?php 
                        $sql = "SELECT id_client FROM achats WHERE id_achat = '$id_buy' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['id_client'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly><br><br>
				</div>


				<div>
					<label for="id_item" class="label">Numero article<span class="required"> * </span></label>
					<input id="id_item" type="number" min="1" name="id_item" class="input" required value="<?php 
                        $sql = "SELECT id_article FROM achats WHERE id_achat = '$id_buy' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['id_article'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly><br><br>
				</div>
				
				<div>
					<label for="qty" class="label" required>Quantite<span class="required"> * </span></label>
					<input id="qty" type="number" min="1" name="qty" class="input" required value="<?php 
                        $sql = "SELECT quantite FROM achats WHERE id_achat = '$id_buy' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['quantite'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<label for="date" class="label" required>Date achat<span class="required"> * </span></label>
					<input id="date" type="date" name="date" class="input" required disabled="" value="<?php 
                        $sql = "SELECT date FROM achats WHERE id_achat = '$id_buy' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['date'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly><br><br>
				</div z>
				
				<div>
					<button type="submit" name="submit_update">MODIFYE</button>
					<button type="reset">EFASE</button>
				</div>
			</form>
		</section>    	
    <?php
?>