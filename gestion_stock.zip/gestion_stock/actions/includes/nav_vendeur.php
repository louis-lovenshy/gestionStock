
<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="includes/css/nav.css">
	<title></title>
</head>
<body> -->

	<aside class="sidenav">
	    <div class="sidenav__close-icon">
	      	<h1>Dashboard</h1>
	    </div>

	    <ul class="sidenav__list">
	    	<img src="images/add.png"><span>AJOUTER</span><hr>
	      	<li class="sidenav__list-item"><a href=".././addCustomers.php">Ajoute Client</a></li>
	      	<li class="sidenav__list-item"><a href=".././addItems.php">Ajoute Article</a></li>
	      	<li class="sidenav__list-item"><a href=".././addBuy.php">Ajoute Achat</a></li>
	      	<div class="separator"></div>

	      	<img src="images/update.png"><span>MODIFIER</span><hr>
	      	<li class="sidenav__list-item"><a href=".././updateCustomers.php">Modifier Client</a></li>
	      	<li class="sidenav__list-item"><a href=".././updateItems.php">Modifier Article</a></li>
	      	<li class="sidenav__list-item"><a href=".././updateBuy.php">Modifier Achat</a></li>
	      	<div class="separator"></div>

	      	<img src="images/liste.png"><span>LISTE</span><hr>
	      	<li class="sidenav__list-item"><a href=".././listCustomers.php">Liste Client</a></li>
	      	<li class="sidenav__list-item"><a href=".././listItems.php">Liste Article</a></li>
	      	<li class="sidenav__list-item"><a href=".././listBuy.php">Liste Achat</a></li>
	      	<div class="separator"></div>

	      	<img src="images/delete.png"><span>SUPPRIMER</span><hr>
	      	<li class="sidenav__list-item"><a href=".././deleteItems.php">Supprimer Article</a></li>
	    </ul>

	    <form method="POST" action="" class="disconnect">
	    	<img src="images/dekonekte.png" class="icon-logout"><button class="log_out" type="submit" name="log_out">Deconnecter</button>
	    </form>

	    <?php
	    	if (isset($_POST['log_out'])) 
	    	{
	    		session_destroy();
	    		header("Location: .././index.php");
	    	}	

	    		if (empty($_SESSION['username']) && empty($_SESSION['fonction'])) 
	    		{
	    			header("Location: .././index.php");
	    			echo "string";
	    		}
	    	// if (!isset($_SESSION['fonction'])) {
	    	// 	header("Location: .././index.php");
	    	// }
	    ?>
  	</aside>
<!-- </body>
</html> -->