
	<header>
		<h1>Gestion Stock</h1>
	</header>
