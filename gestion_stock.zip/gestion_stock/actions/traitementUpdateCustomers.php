<?php
	include '..\connexion_db\config.php';

	if (isset($_POST['id_client']) or isset($_POST['last_name']) or isset($_POST['first_name']) or isset($_POST['nif']) or isset($_POST['adress']) or isset($_POST['postal_code']) or isset($_POST['city']) or isset($_POST['country']) or isset($_POST['telephone']) and isset($_POST['submit_update'])) 
	{
    	$id_client = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_client']));
		$last_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['last_name']));
		$first_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['first_name']));
		$nif = mysqli_real_escape_string($db,htmlspecialchars($_POST['nif']));
		$adress = mysqli_real_escape_string($db,htmlspecialchars($_POST['adress']));
		$postal_code = mysqli_real_escape_string($db,htmlspecialchars($_POST['postal_code']));
		$city = mysqli_real_escape_string($db,htmlspecialchars($_POST['city']));
		$country = mysqli_real_escape_string($db,htmlspecialchars($_POST['country']));
		$telephone = mysqli_real_escape_string($db,htmlspecialchars($_POST['telephone']));



		$requete = "SELECT count(*) FROM clients where nif = '".$nif."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['count(*)'];

        if($count == 1)
        { 
        	$update = "UPDATE clients SET nom = '$last_name', prenom = '$first_name', nif = '$nif', adresse = '$adress', codepostal = '$postal_code', ville = '$city', pays = '$country', telephone = '$telephone' WHERE numero = $id_client"; 

			if (mysqli_query($db, $update)) 
		    {
		        header("Location: ..\listCustomers.php?connect=202&nif=$nif");
		    }
        }

        else
        {
        	header("Location: ..\listCustomers.php?connect=202&nif=$nif");
        }
	}
?>