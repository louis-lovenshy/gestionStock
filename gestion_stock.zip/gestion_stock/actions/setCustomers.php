<?php
	session_start();
	include('..\connexion_db\config.php');

	if (isset($_POST['last_name']) and isset($_POST['first_name']) and isset($_POST['nif']) and isset($_POST['adress']) and isset($_POST['postal_code']) and isset($_POST['city']) and isset($_POST['country']) and isset($_POST['telephone']) and isset($_POST['submit'])) 
	{

		$last_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['last_name']));
		$first_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['first_name']));
		$nif = mysqli_real_escape_string($db,htmlspecialchars($_POST['nif']));
		$adress = mysqli_real_escape_string($db,htmlspecialchars($_POST['adress']));
		$postal_code = mysqli_real_escape_string($db,htmlspecialchars($_POST['postal_code']));
		$city = mysqli_real_escape_string($db,htmlspecialchars($_POST['city']));
		$country = mysqli_real_escape_string($db,htmlspecialchars($_POST['country']));
		$telephone = mysqli_real_escape_string($db,htmlspecialchars($_POST['telephone']));


		//verification client unique
		$sql = "SELECT nif FROM clients WHERE nif = '$nif' ";
        if($result = mysqli_query($db, $sql))
        {
            if(mysqli_num_rows($result) == 0)
            {
            	$insertion = " INSERT INTO clients VALUES (null, '$last_name', '$first_name', '$nif', '$adress', '$postal_code', '$city', '$country', '$telephone') ";

			    if (mysqli_query($db, $insertion)) 
			    {
			        header("Location: ..\listCustomers.php?connect=1&last_name=$last_name&first_name=$first_name");
			    }  
            }

            else
            {
            	header("Location: ..\listCustomers.php?connect=202&nif=$nif");
            }
        }

        else
        {
        	header("Location: ..\listCustomers.php?connect=403");
        }	
	}
?>