<?php
	session_start();

	if (isset($_POST['password']) and isset($_POST['fonction'])) 
	{
		include '../connexion_db/config.php';

		$fonction = mysqli_real_escape_string($db,htmlspecialchars($_POST['fonction']));
		$password = mysqli_real_escape_string($db,htmlspecialchars($_POST['password']));

		$requete = "SELECT count(*) FROM users where fonction = '".$fonction."' AND password = '".$password."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['count(*)'];

        if ($count != 0)
        {
			if ($fonction == "comptable" and $password == "comptable_pass") 
			{
				$_SESSION['username'] = $fonction;
				$_SESSION['fonction'] = $fonction;
				header("Location: ..\listCustomers.php");
			}

			else if ($fonction == "vendeur" and $password == "vendeur_pass") 
			{
				$_SESSION['username'] = $fonction;
				$_SESSION['fonction'] = $fonction;
				?>

				<script type="text/javascript">
					window.location.href = "../vendeurs.php";
				</script>
			<?php }

			else
			{
				echo "ERROR";
			}
		}

		else
		{
			header("Location: ..\index.php?login=0");
		}
	}
?>