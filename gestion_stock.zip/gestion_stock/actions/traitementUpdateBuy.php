<?php
	include '..\connexion_db\config.php';

	if (isset($_POST['id_buy']) or isset($_POST['id_client']) or isset($_POST['id_item']) or isset($_POST['qty']) or isset($_POST['date']) and isset($_POST['submit_update'])) 
	{
    	$id_buy = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_buy']));
		$id_client = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_client']));
		$id_item = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_item']));
		$qty = mysqli_real_escape_string($db,htmlspecialchars($_POST['qty']));
		$date = mysqli_real_escape_string($db,htmlspecialchars($_POST['date']));
	

		$test_3 = "SELECT quantite FROM articles WHERE reference = '".$id_item."' ";
		$exec_requete_3 = mysqli_query($db,$test_3);
        $reponse_3      = mysqli_fetch_array($exec_requete_3); 
        $count_3 = $reponse_3['quantite'];


        if ($count_3 >= $qty) 
        {
        	$update = " UPDATE achats SET quantite = quantite + '$qty' WHERE id_achat = $id_buy ";
        	mysqli_query($db, $update); 

        	$newQty = $count_3 - $qty; 

        	$update = " UPDATE articles SET quantite = '$newQty' WHERE reference = $id_item ";
        	mysqli_query($db, $update);

        	header("Location: ..\listBuy.php?connect=200&id_buy=$id_buy");
        }

        else if($count_3 < $qty)
        {
        	$test_4 = "SELECT nom FROM articles WHERE reference = '".$id_item."' ";
			$exec_requete_4 = mysqli_query($db,$test_4);
	        $reponse_4      = mysqli_fetch_array($exec_requete_4); 
	        $count_4 = $reponse_4['nom'];

        	header("Location: ..\listBuy.php?connect=404&id_item=$id_item&item_name=$count_4");
        }
    }
?>