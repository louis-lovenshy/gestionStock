<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\css\addCustomers.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\nav.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\header.css">
</head>
<body>

</body>
</html>

<?php
	session_start();
	include '../actions/includes/header.php';
	include '../actions/includes/nav_vendeur.php';
	include '..\connexion_db\config.php'
?>

<?php
		if (isset($_POST['id_item']) and isset($_POST['submit_id']))
		{
			include('..\connexion_db\config.php');

			$id_item = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_item']));

			$requete = "SELECT count(*) FROM articles where reference = '".$id_item."' ";
	        $exec_requete = mysqli_query($db,$requete);
	        $reponse      = mysqli_fetch_array($exec_requete); 
	        $count = $reponse['count(*)'];

	        if($count == 1)
	        { ?>
	        	<section class="customers">
        		<?php $sql = "SELECT * FROM articles WHERE reference = '$id_item' ";
	            if($result = mysqli_query($db, $sql))
	            {
	                if(mysqli_num_rows($result) > 0)
	                {
	                    echo "<section>";
	                        
                        // Free result set
                        mysqli_free_result($result);
	                }
	            } 
	        } 

	        else
	        {
	        	header("Location: ..\listItems.php?connect=2&id_item=$id_item");
	        }


	        ?>

	    </section>
		<?php }
	?>


			<form method="POST" action="traitementUpdateItems.php">
				<div>
					<label for="id_item" class="label">Reference Article</label>
					<input id="id_item" type="number" name="id_item" class="input" value="<?php 
                        $sql = "SELECT reference FROM articles WHERE reference = '$id_item' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['reference'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly
                        ><br><br>
				</div>


				<div>
					<label for="item_name" class="label">Nom article<span class="required"> * </span></label>
					<input id="item_name" type="text" minlength="3" maxlength="20" name="item_name" class="input" required value="<?php 
                        $sql = "SELECT nom FROM articles WHERE reference = '$id_item' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['nom'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>" readonly><br><br>
				</div>

				<div>
					<label for="item_desc" class="label">Description<span class="required"> * </span></label>
					<input id="item_desc" type="text" minlength="3" maxlength="20" name="item_desc" class="input" required="" value="<?php 
                        $sql = "SELECT description FROM articles WHERE reference = '$id_item' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['description'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>	
				</div>

				<div>
					<label for="item_qty" class="label" required>Quantite<span class="required"> * </span></label>
					<input id="item_qty" type="number" min="0" name="item_qty" class="input" required value="<?php 
                        $sql = "SELECT quantite FROM articles WHERE reference = '$id_item' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['quantite'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>

				<div>
					<label for="item_price" class="label" required>Prix<span class="required"> * </span></label>
					<input id="item_price" type="number" min="10" name="item_price" class="input" required value="<?php 
                        $sql = "SELECT prix FROM articles WHERE reference = '$id_item' ";
                        
                        if($result = mysqli_query($db, $sql))
                        {
                            if(mysqli_num_rows($result) > 0) 
                            {
                                while($row = mysqli_fetch_array($result)) 
                                {
                                    echo $row['prix'];      
                                }
                                // Free result set
                                mysqli_free_result($result);
                            }
                        }?>"><br><br>
				</div>
				
				<div>
					<button type="submit" name="submit_update">MODIFYE</button>
					<button type="reset">EFASE</button>
				</div>
			</form>
		</section>    	
    <?php
?>