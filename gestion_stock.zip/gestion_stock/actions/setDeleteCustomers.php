<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\css\addCustomers.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\nav.css">
	<link rel="stylesheet" type="text/css" href="..\includes\css\header.css">
</head>
<body>

</body>
</html>

<?php
	session_start();
	include '..\includes\header.php';
	include '..\includes\nav_vendeur.php';
	include '..\connexion_db\config.php'
?>

<?php
	if (isset($_POST['id_customer']) and isset($_POST['submit_id']))
	{
		include('..\connexion_db\config.php');

		$id_customer = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_customer']));

		$requete = "SELECT count(*) FROM clients where numero = '".$id_customer."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['count(*)'];

        if($count !== 0)
        {
    		$sql = "DELETE FROM clients WHERE numero = '$id_customer' ";

   //  		$test_4 = "SELECT nom FROM clients WHERE numero = '".$id_customer."' ";
			// $exec_requete_4 = mysqli_query($db,$test_4);
	  //       $reponse_4      = mysqli_fetch_array($exec_requete_4); 
	  //       $count_4 = $reponse_4['nom'];

            if(mysqli_query($db, $sql))
            {
            	header("Location: ..\listCustomers.php?connect=300");
            }

            else
            {
            	header("Location: ..\listCustomers.php?connect=400");
            } 
        } 

        else
        {
        	header("Location: ..\listCustomers.php?connect=200");
        }

	}
?>