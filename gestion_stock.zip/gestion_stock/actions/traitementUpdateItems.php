<?php
	include '..\connexion_db\config.php';

	if (isset($_POST['id_item']) or isset($_POST['item_name']) or isset($_POST['item_desc']) or isset($_POST['item_qty']) or isset($_POST['item_price']) and isset($_POST['submit_update'])) 
	{
    	$id_item = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_item']));
		$item_name = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_name']));
		$item_desc = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_desc']));
		$item_qty = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_qty']));
		$item_price = mysqli_real_escape_string($db,htmlspecialchars($_POST['item_price']));
		

		$requete = "SELECT count(*) FROM articles where nom = '".$item_name."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count = $reponse['count(*)'];

        if($count != 0)
        { 
        	$update = " UPDATE articles SET nom = '$item_name', description = '$item_desc', quantite = '$item_qty', prix = '$item_price' WHERE reference = $id_item "; 

			if (mysqli_query($db, $update)) 
		    {
		        header("Location: ..\listItems.php?connect=203&id_item=$id_item");
		    }
        }

        else
        {
        	header("Location: ..\listItems.php?connect=202");
        }
	}
?>