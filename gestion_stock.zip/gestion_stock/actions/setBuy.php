<?php
	session_start();

	if (isset($_POST['id_client']) and isset($_POST['id_item']) and isset($_POST['qty'])) 
	{
		include('..\connexion_db\config.php');

		$id_client = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_client']));
		$id_item = mysqli_real_escape_string($db,htmlspecialchars($_POST['id_item']));
		$qty = mysqli_real_escape_string($db,htmlspecialchars($_POST['qty']));



		$test_1 = "SELECT count(*) FROM clients WHERE numero = '".$id_client."' ";
        $exec_requete = mysqli_query($db,$test_1);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count_1 = $reponse['count(*)'];


        $test_2 = "SELECT count(*) FROM articles WHERE reference = '".$id_item."' ";
        $exec_requete = mysqli_query($db,$test_2);
        $reponse      = mysqli_fetch_array($exec_requete); 
        $count_2 = $reponse['count(*)'];
		
		$test_3 = "SELECT quantite FROM articles WHERE reference = '".$id_item."' ";
		$exec_requete_3 = mysqli_query($db,$test_3);
        $reponse_3      = mysqli_fetch_array($exec_requete_3); 
        $count_3 = $reponse_3['quantite'];



        if ($count_1 == 0)
        {
            header("Location: ..\listItems.php?connect=405&id_client=$id_client");
        }

        if ($count_2 == 0)
        {
            header("Location: ..\listItems.php?connect=406&id_item=$id_item");
        }

        if ($count_1 == 0 and $count_2 == 0)
        {
            header("Location: ..\listItems.php?connect=407&id_client=$id_client&id_item=$id_item");
        }




        elseif ($count_1 !== 0 and $count_2 !== 0 and $count_3 >= $qty) 
        {
        	$insertion = "INSERT INTO achats VALUES (null, $id_client, $id_item, '$qty', CURRENT_TIMESTAMP)";

		    if (mysqli_query($db, $insertion)) 
		    {
		    	$newQty = $count_3 - $qty; 
		    	$test_4 = "UPDATE articles SET quantite = '$newQty' WHERE reference = '".$id_item."' ";
		    	if (mysqli_query($db, $test_4))
		    	{
		    		header('Location: ..\listBuy.php?connect=1');
		    	}     
		    }       
        }


        //stock insuffisant
        elseif ($count_1 !== 0 and $count_2 !== 0 and $count_3 < $qty)
        {
        	$test_5 = "SELECT nom FROM articles WHERE reference = '".$id_item."' ";	
        	$exec_requete_5 = mysqli_query($db,$test_5);
			$reponse_5      = mysqli_fetch_array($exec_requete_5); 
			$count_5 = $reponse_5['nom'];
        	header("Location: ..\listItems.php?connect=404&id_item=$id_item&item_name=$count_5");
        }
	}
?>



