<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/addCustomers.css">
</head>
	
<body>
	<?php
		session_start(); 
		include './includes/header.php';
		include 'includes/nav_vendeur.php';
	?>

    <section class="customers">
    	<h1>INSERER ACHAT</h1>
    	<form method="POST" action="actions/setBuy.php">
			<div>
				<label for="id_client" class="label">NUMERO CLIENT <span class="required"> * </span></label>
				<input id="id_client" type="number" min="1" name="id_client" class="input" required><br><br>
			</div>

			<div>
				<label for="id_item" class="label">NUMERO ARTICLE<span class="required"> * </span></label>
				<input id="id_item" type="number" min="1" name="id_item" class="input" required><br><br>
			</div>
			
			<div>
				<label for="qty" class="label" required>QUANTITE<span class="required"> * </span></label>
				<input id="qty" type="number" min="1" name="qty" class="input" required><br><br>
			</div>

			<div>
				<label for="date" class="label" required>DATE ACHAT<span class="required"> * </span></label>
				<input id="date" type="date" name="date" class="input" required disabled=""><br><br>
			</div>
			
			<div>
				<button type="submit" name="submit">INSERER</button>
				<button type="reset">EFFACER</button>
			</div>
		</form>
    </section>	
</body>
</html>