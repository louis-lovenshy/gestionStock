<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/list.css"/>
        <title>Liste clients</title>
    </head>

    <body>
        <?php
            session_start();

            if(isset($_GET['connect']))
            {
                $conn = $_GET['connect'];

                if($conn == 1)
                { ?>
                    <script type="text/javascript">
                        alert("Achat Enregistrer !");
                    </script>
                <?php }


                else if($conn == 2 and isset($_GET['id_buy']))
                { 
                    $id_buy = $_GET['id_buy']; ?>
                    <script type="text/javascript">
                        alert("Achat ID <?php echo "$id_buy"; ?> n'existe pas !");
                    </script>
                <?php }
                else if($conn == 200)
                { ?>
                    <script type="text/javascript">
                        alert("ID Achat Invalide");
                    </script>
                <?php }

                else if($conn == 300)
                { ?>
                    <script type="text/javascript">
                        alert("Achat Supprime");
                    </script>
                <?php }

                else if($conn == 400)
                { ?>
                    <script type="text/javascript">
                        alert("Impossible de supprimer cet achat (cle etrangere)");
                    </script>
                <?php }

                else if($conn == 404 and isset($_GET['id_item']) and isset($_GET['item_name']))
                { 
                    $id_item = $_GET['id_item'];
                    $item_name = $_GET['item_name'];

                    ?>
                    <script type="text/javascript">
                        alert("Stock Article <?php echo "$item_name"; ?> De Reference <?php echo "$id_item"; ?> Insuffisant !");
                    </script>
                <?php }


                else if($conn == 200 and isset($_GET['id_buy']))
                { 
                    $id_buy = $_GET['id_buy'];

                    ?>
                    <script type="text/javascript">
                        alert("Achat ID  <?php echo "$id_buy"; ?> Modifier");
                    </script>
                <?php }

                else
                { ?>
                    <script type="text/javascript">
                        alert("Achat Non Enregistrer !");
                    </script>
                <?php } ?>
                    <script type="text/javascript">
                        window.location.href = "listBuy.php";
                    </script> <?php
            } 

            if ($_SESSION['fonction'] == "comptable") 
            {
                include './includes/header.php';
                include './includes/nav_comptable.php';
                include './connexion_db/config.php';
        
                $sql = "SELECT * FROM achats";
                echo "<section>";
                            echo "<h1>LISTE ACHATS</h1>";
                            echo "<table>";
                                echo "<tr>";
                                    echo "<th>ID Achat</th>";
                                    echo "<th>ID Client</th>";
                                    echo "<th>ID Article</th>";
                                    echo "<th>Quantite</th>";
                                    echo "<th>Date Achat</th>";    
                                echo "</tr>";
                if($result = mysqli_query($db, $sql))
                {
                    if(mysqli_num_rows($result) > 0)
                    {
                        

                                while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                        echo "<td>" . $row['id_achat'] . "</td>";
                                        echo "<td>" . $row['id_client'] . "</td>";
                                        echo "<td>" . $row['id_article'] . "</td>";
                                        echo "<td>" . $row['quantite'] . "</td>";
                                        echo "<td>" . $row['date'] . "</td>";
                                    echo "</tr>";
                                }

                                
                                // Free result set
                                mysqli_free_result($result);
                    }
                } 
                    echo "</table>";
                echo "</section>";
                 
                // Close connection
                mysqli_close($db);
            }


            if ($_SESSION['fonction'] == "vendeur") 
            {
                include './includes/header.php';
                include './includes/nav_vendeur.php';
                include './connexion_db/config.php';
        
                $sql = "SELECT * FROM achats";
                echo "<section>";
                        echo "<h1>LISTE ACHATS</h1>";
                            echo "<table>";
                                echo "<tr>";
                                    echo "<th>ID Achat</th>";
                                    echo "<th>ID Client</th>";
                                    echo "<th>ID Article</th>";
                                    echo "<th>Quantite</th>";
                                    echo "<th>Date Achat</th>";    
                                echo "</tr>";
                if($result = mysqli_query($db, $sql))
                {
                    if(mysqli_num_rows($result) > 0)
                    {
                        

                                while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                        echo "<td>" . $row['id_achat'] . "</td>";
                                        echo "<td>" . $row['id_client'] . "</td>";
                                        echo "<td>" . $row['id_article'] . "</td>";
                                        echo "<td>" . $row['quantite'] . "</td>";
                                        echo "<td>" . $row['date'] . "</td>";
                                    echo "</tr>";
                                }

                                
                                // Free result set
                                mysqli_free_result($result);
                    }
                } 
                    echo "</table>";
                echo "</section>";
                 
                // Close connection
                mysqli_close($db);
            }
        ?>

    </body>
</html>
