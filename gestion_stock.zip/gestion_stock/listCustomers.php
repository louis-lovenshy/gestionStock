<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/list.css"/>
        <title>Liste clients</title>
    </head>

    <body>
        <?php
            session_start();


            if(isset($_GET['connect']))
            {
                $conn = $_GET['connect'];

                
                // Confirmation ajout client
                if($conn == 1 and isset($_GET['last_name']) and isset($_GET['first_name']))
                { 
                    $last_name = $_GET['last_name'];
                    $first_name = $_GET['first_name'];

                    ?>
                    <script type="text/javascript">
                        alert("<?php echo $last_name." ".$first_name; ?> Inserer !");
                    </script>
                <?php }


                // Client non trouve
                else if($conn == 2 and isset($_GET['id_client']))
                { 
                    $id_client = $_GET['id_client']; ?>
                    <script type="text/javascript">
                        alert("Client ID <?php echo $id_client; ?> N'existe Pas");
                    </script>
                <?php }

                else if($conn == 200)
                { ?>
                    <script type="text/javascript">
                        alert("ID Client Invalide");
                    </script>
                <?php }

                else if($conn == 300)
                { ?>
                    <script type="text/javascript">
                        alert("Client Supprime");
                    </script>
                <?php }

                else if($conn == 400)
                { ?>
                    <script type="text/javascript">
                        alert("Impossible de supprimer ce client (cle etrangere)");
                    </script>
                <?php }

                else if($conn == 202 and isset($_GET['nif']))
                { 
                    $nif = $_GET['nif']; ?>

                    <script type="text/javascript">
                        alert("Client NIF <?php echo $nif; ?> Modifier");
                    </script>
                <?php }

                else if($conn == 202 and isset($_GET['nif']))
                { 
                    $nif = $_GET['nif']; ?>
                    <script type="text/javascript">
                        alert("Client NIF <?php echo "$nif"; ?> Existe Deja !");
                    </script>
                <?php }

                else
                { ?>
                    <script type="text/javascript">
                        alert("Client Non Inserer");
                    </script>
                <?php }?>
                    <script type="text/javascript">
                        window.location.href = "listCustomers.php";
                    </script> <?php
            }

            if (isset($_SESSION['fonction']) && !empty($_SESSION['fonction'])) {
                if ($_SESSION['fonction'] == "comptable") 
                {
                    include './includes/header.php';
                    include './includes/nav_comptable.php';
                    include './connexion_db/config.php';


                    $sql = "SELECT * FROM clients";
                    echo "<section>";
                                echo "<h1>LISTE CLIENTS</h1>";
                                echo "<table>";
                                    echo "<tr>";
                                        echo "<th>ID Client</th>";
                                        echo "<th>Nom</th>";
                                        echo "<th>Prenom</th>";
                                        echo "<th>NIF</th>";
                                        echo "<th>Adresse</th>";
                                        echo "<th>Code Postal</th>";
                                        echo "<th>Ville</th>";
                                        echo "<th>Pays</th>";
                                        echo "<th>Telephone</th>";    
                                    echo "</tr>";
                    if($result = mysqli_query($db, $sql))
                    {
                        if(mysqli_num_rows($result) > 0)
                        {
                            

                                    while($row = mysqli_fetch_array($result))
                                    {
                                        echo "<tr>";
                                            echo "<td>" . $row['numero'] . "</td>";
                                            echo "<td>" . $row['nom'] . "</td>";
                                            echo "<td>" . $row['prenom'] . "</td>";
                                            echo "<td>" . $row['nif'] . "</td>";
                                            echo "<td>" . $row['adresse'] . "</td>";                            
                                            echo "<td>" . $row['codepostal'] . "</td>";
                                            echo "<td>" . $row['ville'] . "</td>";
                                            echo "<td>" . $row['pays'] . "</td>";
                                            echo "<td>" . $row['telephone'] . "</td>";
                                            echo "<td></td>";
                                        echo "</tr>";
                                    }

                                    
                                    // Free result set
                                    mysqli_free_result($result);
                        }
                    } 
                        echo "</table>";
                    echo "</section>";
                }


                elseif ($_SESSION['fonction'] == "vendeur") 
                {
                    include './includes/header.php';
                    include './includes/nav_vendeur.php';
                    include './connexion_db/config.php';


                    $sql = "SELECT * FROM clients";
                    echo "<section>";
                                echo "<h1>LISTE CLIENTS</h1>";
                                echo "<table>";
                                    echo "<tr>";
                                        echo "<th>ID Client</th>";
                                        echo "<th>Nom</th>";
                                        echo "<th>Prenom</th>";
                                        echo "<th>NIF</th>";
                                        echo "<th>Adresse</th>";
                                        echo "<th>Code Postal</th>";
                                        echo "<th>Ville</th>";
                                        echo "<th>Pays</th>";
                                        echo "<th>Telephone</th>";    
                                    echo "</tr>";
                    if($result = mysqli_query($db, $sql))
                    {
                        if(mysqli_num_rows($result) > 0)
                        {
                            

                                    while($row = mysqli_fetch_array($result))
                                    {
                                        echo "<tr>";
                                            echo "<td>" . $row['numero'] . "</td>";
                                            echo "<td>" . $row['nom'] . "</td>";
                                            echo "<td>" . $row['prenom'] . "</td>";
                                            echo "<td>" . $row['nif'] . "</td>";
                                            echo "<td>" . $row['adresse'] . "</td>";                            
                                            echo "<td>" . $row['codepostal'] . "</td>";
                                            echo "<td>" . $row['ville'] . "</td>";
                                            echo "<td>" . $row['pays'] . "</td>";
                                            echo "<td>" . $row['telephone'] . "</td>";
                                            echo "<td></td>";
                                        echo "</tr>";
                                    }

                                    
                                    // Free result set
                                    mysqli_free_result($result);
                        }
                    } 
                        echo "</table>";
                    echo "</section>";
                    }
                
            }
            else 
            {
                header("Location: index.php");
            }
        ?>
    </body>
</html>
