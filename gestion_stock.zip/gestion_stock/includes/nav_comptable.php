<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> -->
	<link rel="stylesheet" type="text/css" href="includes/css/nav.css">
	<title>Comptable</title>
<!-- </head> -->
<body>
	<aside class="sidenav">
	    <div class="sidenav__close-icon">
	      	<h1>MENU</h1>
	    </div>

	    <ul class="sidenav__list">
	      	<img src="images/liste.png"><span>LISTE</span><hr>
	      	<li class="sidenav__list-item"><a href="listCustomers.php">LISTE CLIENTS</a></li>
	      	<li class="sidenav__list-item"><a href="listItems.php">LISTE ARTICLES</a></li>
	      	<li class="sidenav__list-item"><a href="listBuy.php">LISTE ACHATS</a></li>
	    </ul>

	    <form method="POST" action="">
	    	<img src="images/dekonekte.png"><button class="log_out" type="submit" name="log_out">DECONNEXION</button>
	    </form>

	    <?php
	    	if (isset($_POST['log_out'])) 
	    	{
	    		header("Location: index.php");
	    		session_destroy();

	    		
	    	}
	    	if (empty($_SESSION['fonction'])) 
	    		{
	    			header("Location: index.php");
	    		}
	    ?>
  	</aside>
<!-- </body>
</html> -->