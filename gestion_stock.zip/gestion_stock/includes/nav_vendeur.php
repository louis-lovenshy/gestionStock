<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="includes/css/nav.css">
	<title>Vendeur</title>
</head>
<body>
	<?php
		include 'header.php';

	?>

	<aside class="sidenav">
	    <div class="sidenav__close-icon">
	      	<h1>MENU</h1>
	    </div>

	    <ul class="sidenav__list">
	    	<img src="images/add.png"><span>INSERTION</span><hr>
	      	<li class="sidenav__list-item"><a href="addCustomers.php">INSERER CLIENT</a></li>
	      	<li class="sidenav__list-item"><a href="addItems.php">INSERER ARTICLE</a></li>
	      	<li class="sidenav__list-item"><a href="addBuy.php">INSERER ACHAT</a></li>
	      	<div class="separator"></div>

	      	<img src="images/update.png"><span>MODIFICATION</span><hr>
	      	<li class="sidenav__list-item"><a href="updateCustomers.php">MODIFIER CLIENT</a></li>
	      	<li class="sidenav__list-item"><a href="updateItems.php">MODIFIER ARTICLE</a></li>
	      	<li class="sidenav__list-item"><a href="updateBuy.php">MODIFIER ACHAT</a></li>
	      	<div class="separator"></div>

	      	<img src="images/liste.png"><span>LISTE</span><hr>
	      	<li class="sidenav__list-item"><a href="listCustomers.php">LISTE CLIENTS</a></li>
	      	<li class="sidenav__list-item"><a href="listItems.php">LISTE ARTICLES</a></li>
	      	<li class="sidenav__list-item"><a href="listBuy.php">LISTE ACHATS</a></li>
	      	<div class="separator"></div>

	      	<img src="images/delete.png"><span>SUPPRESSION</span><hr>
	      	<li class="sidenav__list-item"><a href="deleteCustomers.php">SUPPRIMER CLIENTS</a></li>
	      	<li class="sidenav__list-item"><a href="deleteItems.php">SUPPRIMER ARTICLES</a></li>
	      	<li class="sidenav__list-item"><a href="deleteBuy.php">SUPPRIMER ARTICLES</a></li>
	    </ul>

	    <form method="POST" action="" class="disconnect">
	    	<img src="images/dekonekte.png" class="icon-logout"><button class="log_out" type="submit" name="log_out">DECONNEXION</button>
	    </form>

	    <?php
	    	if (isset($_POST['log_out'])) 
	    	{
	    		header("Location: index.php");
	    		session_destroy();

	    		
	    	}

	    	if (empty($_SESSION['username']) || empty($_SESSION['fonction'])) 
	    		{
	    			header("Location: index.php");
	    		}
	    ?>
  	</aside>
</body>
</html>