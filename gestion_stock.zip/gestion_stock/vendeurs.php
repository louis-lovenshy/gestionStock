<?php
	session_start();

	
	include 'includes/nav_vendeur.php';
	// include 'includes/header.php';
?>