<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/addCustomers.css">
</head>
	
<body>
	<?php 
		session_start();
		include 'includes/header.php';
		include 'includes/nav_vendeur.php';
	?>

	<section class="customers">
		<h1>MODIFIER CLIENT</h1>
		<form method="POST" action="actions/setUpdateCustomers.php">
			<div>
				<label for="id_client" class="label">ID CLIENT</label>
				<input id="id_client" type="number" name="id_client" class="input" required><br><br>
			</div>

			<div>
				<button type="submit" name="submit_id">ENVOYER</button>
			</div>
		</form>
	</section>


	
	
</body>
</html>