<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/addCustomers.css">
</head>
	
<body>
	<?php 
		session_start();
		include 'includes/header.php';
		include 'includes/nav_vendeur.php';
	?>

	<section class="customers">
		<h1>SUPPRIMER CLIENTS</h1>
		<form method="POST" action="actions/setDeleteCustomers.php">
			<div>
				<label for="id_item" class="label">ID CLIENT</label>
				<input id="id_item" type="number" name="id_customer" class="input" required><br><br>
			</div>

			<div>
				<button type="submit" name="submit_id">ENVOYER</button>
			</div>
		</form>
	</section>
</body>
</html>