<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/addCustomers.css">
</head>
	
<body>
	<?php 
		session_start();
		include 'includes/header.php';
		include 'includes/nav_vendeur.php';
	?>

	<section class="customers">
		<h1>INSERER ARTICLE</h1>
		<form method="POST" action="actions/setItems.php">
			<div>
				<label for="item_name" class="label">NOM ARTICLE<span class="required"> * </span></label>
				<input id="item_name" type="text" minlength="3" maxlength="20" name="item_name" class="input" required><br><br>
			</div>

			<div>
				<label for="item_desc" class="label">DESCRIPTION<span class="required"> * </span></label>
				<input id="item_desc" type="text" minlength="3" maxlength="20" name="item_desc" class="input" required=""><br><br>	
			</div>

			<div>
				<label for="item_qty" class="label" required>QUANTITE<span class="required"> * </span></label>
				<input id="item_qty" type="number" min="1" name="item_qty" class="input" required><br><br>
			</div>

			<div>
				<label for="item_price" class="label" required>PRIX<xspan class="required"> * </span></label>
				<input id="item_price" type="number" min="10" name="item_price" class="input" required><br><br>
			</div>

			<div>
				<button type="submit" name="submit">INSERER</button>
				<button type="reset">EFFACER</button>
			</div>
		</form>
	</section>
</body>
</html>